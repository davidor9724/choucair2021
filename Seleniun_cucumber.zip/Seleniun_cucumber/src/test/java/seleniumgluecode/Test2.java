package seleniumgluecode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

public class Test2 extends Testbase {

    @Given("^el usuario selecciona la opcion de contactenos$")
    public void el_usuario_selecciona_la_opcion_de_contactenos() throws Throwable {
        Assert.assertEquals(compra.getTitleprenda(), driver.getTitle());
        WebElement ImagePrenda = driver.findElement(compra.getContactus());
        ImagePrenda.click();
        driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
    }

    @When("^hace clic sobre el boton Contact us$")
    public void hace_clic_sobre_el_boton_Contact_us() throws Throwable {
        Select oldStyleMenu = new Select(driver.findElement(compra.getSubjectHeading()));
        oldStyleMenu.selectByIndex(1);
        WebElement Email = driver.findElement(compra.getEmailaddress());
        Email.sendKeys("davidor9724@gmail.com");
        driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
    }

    @Then("^debe llenar los campos del formulario$")
    public void debe_llenar_los_campos_del_formulario() throws Throwable {
        WebElement TextMessage = driver.findElement(compra.getMessage());
        TextMessage.sendKeys("Prueba de envio para contactenos");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Then("^selecciona el boton enviar$")
    public void selecciona_el_boton_enviar() throws Throwable {
        WebElement Send = driver.findElement(compra.getSend());
        Send.click();
    }
}
