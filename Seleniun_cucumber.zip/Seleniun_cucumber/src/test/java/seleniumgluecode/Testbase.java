package seleniumgluecode;

import org.openqa.selenium.chrome.ChromeDriver;
import pom.Contactenos;
import pom.homepage;
import pom.searchpage;

public class Testbase {

    protected ChromeDriver driver = Hooks.getDriver();
    protected homepage homePage = new homepage();
    protected searchpage searchPage = new searchpage();
    protected Contactenos compra = new Contactenos();
}
