package seleniumgluecode;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hooks {
    private static ChromeDriver driver;
    private static int numberofcase = 0;

    @Before
    public void setUp(){
        numberofcase ++;
        System.out.println("Se esta ejecutando el Escenario numero: "+ numberofcase);
        System.setProperty("webdriver.chrome.driver","./src/test/resources/chromedriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();
    }
@After
    public void tearDown(){
        System.out.println("El escenario numero: " + numberofcase + "Se ejecuto correctamente.");
        driver.quit();
    }

    public static ChromeDriver getDriver(){
        return driver;
    }
}
