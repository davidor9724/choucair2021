package seleniumgluecode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

public class test extends Testbase{

    @Given("^el usuario se encuentra en la pagina home de newexperience$")
    public void el_usuario_se_encuentra_en_la_pagina_home_de_newexperience() throws Throwable {
        Assert.assertEquals(homePage.getTitlehomepqage(), driver.getTitle());
    }

    @When("^hace clic sobre el campo buscar$")
    public void hace_clic_sobre_el_boton_de_little_tester_comics() throws Throwable {
        driver.manage().timeouts().implicitlyWait(05, TimeUnit.SECONDS);
        WebElement titlesearchlocator = driver.findElement(homePage.getTitlesearchlocator());
        titlesearchlocator.sendKeys("DRESSES");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement searchlocator = driver.findElement(homePage.getSearchlocator());
        searchlocator.click();
    }

    @Then("^se debe redirigir a la pantalla de search$")
    public void se_debe_redirigir_a_la_pantalla_de_search() throws Throwable {
        WebElement pagetitlelocator = driver.findElement(searchPage.getPagetitlelocator());
        Assert.assertTrue("No se redirecciono correctamente a la pagina de comics", pagetitlelocator.isDisplayed());
        Assert.assertEquals(searchPage.getTitlesearch(), pagetitlelocator.getText());
    }
}
