package pom;

import org.openqa.selenium.By;

public class homepage {
    private String titlehomepqage = "My Store";
    private By titlesearchlocator = By.id("search_query_top");
    private By searchlocator = By.name("submit_search");

    public String getTitlehomepqage() {
        return titlehomepqage;
    }

    public By getTitlesearchlocator() {
        return titlesearchlocator;
    }

    public By getSearchlocator() {
        return searchlocator;
    }
}
