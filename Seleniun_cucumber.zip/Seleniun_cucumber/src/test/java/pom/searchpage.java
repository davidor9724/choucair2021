package pom;

import org.openqa.selenium.By;

public class searchpage {
    private By pagetitlelocator = By.xpath("//SPAN[@class='navigation_page'][text()='Search']");
    private String titlesearch = "Search";

    public By getPagetitlelocator() {
        return pagetitlelocator;
    }

    public String getTitlesearch() {
        return titlesearch;
    }
}
