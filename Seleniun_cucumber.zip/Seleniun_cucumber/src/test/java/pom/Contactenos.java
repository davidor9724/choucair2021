package pom;

import org.openqa.selenium.By;

public class Contactenos {
    private String titleprenda = "My Store";
    private By Contactus = By.id("contact-link");
    private By SubjectHeading = By.id("id_contact");
    private By Emailaddress = By.id("email");
    private By Message = By.id("message");
    private By Send = By.id("submitMessage");

    public String getTitleprenda() { return titleprenda; }
    public By getContactus() { return Contactus;  }
    public By getSubjectHeading() { return SubjectHeading;  }
    public By getEmailaddress() { return Emailaddress;  }
    public By getMessage() {  return Message;  }
    public By getSend() {return Send;}
}
